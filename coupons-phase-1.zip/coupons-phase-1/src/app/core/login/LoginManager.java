package app.core.login;

import app.core.facade.AdminFacade;
import app.core.facade.ClientFacade;
import app.core.facade.CompanyFacade;
import app.core.facade.CustomerFacade;

public class LoginManager {

	private static LoginManager instance;
		
	public LoginManager() {
	}

	public LoginManager(LoginManager instance) {
		LoginManager.instance = instance;
	}

	public static LoginManager getInstance() {
		if (instance == null) {
			instance = new LoginManager();
		}
		return instance;
	}


	public ClientFacade login(String email, String password,ClientType clientType) {
		if (clientType == ClientType.ADMINISTRADOR) {
			AdminFacade adminFacade = new AdminFacade();
			if (adminFacade.login(email, password)) {
			return adminFacade;	
			}
		}
		if (clientType == ClientType.COMPANY) {
			CompanyFacade companyFacade = new CompanyFacade();
			if (companyFacade.login(email, password)) {
				return companyFacade;
			}
		}
		if (clientType == ClientType.CUSTOMER) {
			CustomerFacade customerFacade = new CustomerFacade();
			if (customerFacade.login(email, password)) {
				return customerFacade;
			}
		}
		return null;
	}
	
}


