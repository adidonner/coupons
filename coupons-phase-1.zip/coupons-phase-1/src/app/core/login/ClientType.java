package app.core.login;

public enum ClientType {
	ADMINISTRADOR, COMPANY, CUSTOMER;
}
