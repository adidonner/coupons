package app.core.facade;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;

import app.core.beans.Category;
import app.core.beans.Company;
import app.core.beans.Coupon;
import app.core.beans.CustomerVsCoupon;
import app.core.data.dao.CompanyDao;
import app.core.data.dao.CompanyDaoDbPreparedStatements;
import app.core.data.dao.CouponDao;
import app.core.data.dao.CouponDaoDbPreparedStatements;
import app.core.data.dao.CustomerVsCouponDao;
import app.core.data.dao.CustomerVsCouponDaoDbPreparedStatements;
import app.core.exceptions.CompaniesException;

public class CompanyFacade extends ClientFacade {

	private int id;

	public CompanyFacade() {
	}

	
	public CompanyFacade(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean login(String email, String password) {
		CompanyDao dao = new CompanyDaoDbPreparedStatements();
		List<Company> Companies = new ArrayList<>(dao.readAll());
		Iterator<Company> it = Companies.iterator();
		while (it.hasNext()) {
			Company curr = it.next();
			if (curr.getEmail().equals(email) && curr.getPassword().equals(password)) {
				setId(curr.getId()); // Company access only to its own information
				System.out.println("company " + getCompanyDetails().getName() + " logged in");
				return true;
			}
		}
		System.out.println("Null");
		return false;
	}

	public Company getCompanyDetails() {
		CompanyDao dao = new CompanyDaoDbPreparedStatements();
		return dao.read(getId());
	}

	public boolean addCoupon(Coupon coupon) {
		try {
			CouponDao dao = new CouponDaoDbPreparedStatements();
			List<Coupon> coupons = new ArrayList<Coupon>(dao.readAll());
			Iterator<Coupon> it = coupons.iterator();
			while (it.hasNext()) {
				Coupon curr = it.next();
				if (coupon.getTitle().equals(curr.getTitle())) {
					System.out.println("coupon alraedy exists");
					return false;
				}
			}
			dao.create(coupon);
			return true;
		} catch (CompaniesException e) {
			throw new CompaniesException("add coupon failed", e);
		}

	}

	public List<Coupon> getAllCompanyCoupons() {
		try {
			CouponDao dao = new CouponDaoDbPreparedStatements();
			List<Coupon> companyCoupons = new ArrayList<>();
			List<Coupon> coupons = new ArrayList<>(dao.readAll());
			Iterator<Coupon> it = coupons.iterator();
			while (it.hasNext()) {
				Coupon curr = it.next();
				if (curr.getCompanyId() == id) {
					companyCoupons.add(curr);
				}
			}
			return companyCoupons;
		} catch (CompaniesException e) {
			throw new CompaniesException("read coupon failed", e);
		}
	}

	public Coupon getCompanyCoupon(int couponId) {
		try {
			List<Coupon> coupons = new ArrayList<>(getAllCompanyCoupons());
			Iterator<Coupon> it = coupons.iterator();
			while (it.hasNext()) {
				Coupon curr = it.next();
				if (curr.getId() == couponId) {
					return curr;
				}
			}
		} catch (CompaniesException e) {
			throw new CompaniesException("read coupon failed", e);
		}
		return null;
	}

	public void updateCompanyCoupon(Coupon coupon) {
		try {
			CouponDao dao = new CouponDaoDbPreparedStatements();
			dao.update(coupon);

		} catch (CompaniesException e) {
			throw new CompaniesException("update coupon failed", e);
		}

	}

	public boolean deleteCompanyCoupon(int couponId) {
		try {
			List<Coupon> coupons = new ArrayList<>(getAllCompanyCoupons());
			Iterator<Coupon> it = coupons.iterator();
			while (it.hasNext()) {
				Coupon curr = it.next();
				if (curr.getId() == couponId) {
					CustomerVsCouponDao dao1 = new CustomerVsCouponDaoDbPreparedStatements();
					List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>(dao1.readAll());
					Iterator<CustomerVsCoupon> it1 = customerVsCoupons.iterator();
					while (it1.hasNext()) {
						CustomerVsCoupon curr1 = it1.next();
						if (curr1.getCouponId() == couponId) {
							dao1.deleteCoupon(couponId);
							System.out.println("coupon deleted from customer history");
						}
					}
					CouponDao dao = new CouponDaoDbPreparedStatements();
					dao.delete(couponId);
					return true;
				}
			}
			System.out.println("coupon doesn't exist");
			return false;
		} catch (CompaniesException e) {
			throw new CompaniesException("delete coupon failed", e);
		}

	}

	public List<Coupon> getAllCategoryCompanyCoupons(Category category) {
		try {
			List<Coupon> coupons = new ArrayList<>(getAllCompanyCoupons());
			List<Coupon> companyCoupons = new ArrayList<>();
			Iterator<Coupon> it = coupons.iterator();
			while (it.hasNext()) {
				Coupon curr = it.next();
				if (curr.getCategory() == category) {
					companyCoupons.add(curr);
				}
			}
			return companyCoupons;
		} catch (CompaniesException e) {
			throw new CompaniesException("read coupon failed", e);
		}
	}

	public List<Coupon> getAllMaxCompanyCoupons(double maxPrice) {
		try {
			List<Coupon> coupons = new ArrayList<>(getAllCompanyCoupons());
			List<Coupon> maxCoupons = new ArrayList<>();
			Iterator<Coupon> it = coupons.iterator();
			while (it.hasNext()) {
				Coupon curr = it.next();
				if (curr.getPrice() <= maxPrice) {
					maxCoupons.add(curr);
				}
			}
			return maxCoupons;
		} catch (CompaniesException e) {
			throw new CompaniesException("read coupons failed", e);
		}
	}

}
