package app.core.facade;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import app.core.beans.Company;
import app.core.beans.Coupon;
import app.core.beans.Customer;
import app.core.data.dao.CompanyDao;
import app.core.data.dao.CompanyDaoDbPreparedStatements;
import app.core.data.dao.CustomerDao;
import app.core.data.dao.CustomerDaoDbPreparedStatements;
import app.core.exceptions.CompaniesException;

public class AdminFacade extends ClientFacade {

	private String adminEmail = "email@admin.com";
	private String adminPassword = "admin";

	public AdminFacade() {
	}

	public boolean login(String email, String password) {
		if (adminEmail.equals(email) && adminPassword.equals(password)) {
			System.out.println("welcome  administrator you are logged in");
			return true;
		}
		System.out.println("Null");
		System.exit(0);
		return false;

	}

	public void addCompany(Company company) {
		try {
			List<Company> companies = new ArrayList<>(getAllCompanies());
			if (companies.contains(company)) {
				System.out.println("company already exists");
				return;
			}
			Iterator<Company> it = companies.iterator();
			while (it.hasNext()) {
				Company curr = it.next();
				if (curr.getName().equals(company.getName())) {
					System.out.println("Company name already used");
					return;
				}
				if (curr.getEmail().equals(company.getEmail())) {
					System.out.println("email already used");
					return;
				}
			}
			CompanyDao dao = new CompanyDaoDbPreparedStatements();
			dao.create(company);
			System.out.println("company Id: " + company.getId() + " added successfully");
		} catch (CompaniesException e) {
			throw new CompaniesException("add company failed", e);
		}

	}

	public Company getOneCompany(int companyId) {
		try {
			CompanyDao dao = new CompanyDaoDbPreparedStatements();
			return dao.read(companyId);
		} catch (CompaniesException e) {
			throw new CompaniesException("get company failed", e);
		}
	}

	public List<Company> getAllCompanies() {
		try {
			CompanyDao dao = new CompanyDaoDbPreparedStatements();
			return dao.readAll();
		} catch (CompaniesException e) {
			throw new CompaniesException("get all companies failed", e);
		}

	}

	public void updateCompany(Company company) {
		try {
			List<Company> companies = new ArrayList<>(getAllCompanies());
			Iterator<Company> it = companies.iterator();
			while (it.hasNext()) {
				Company curr = it.next();
				if (curr.getId() == company.getId() && !curr.getName().equals(company.getName())) {
					System.out.println("Company name already used in other id");
					return;
				}
				if (curr.getId() == company.getId() && !curr.getName().equals(company.getName())) {
					System.out.println("company name can not be changed");
					return;
				}
			}
			CompanyDao dao = new CompanyDaoDbPreparedStatements();
			dao.update(company);
		} catch (CompaniesException e) {
			throw new CompaniesException("update company failed", e);
		}

	}

	public void deleteCompany(int companyId) {
		try {
			List<Company> companies = new ArrayList<>(getAllCompanies());
			for (Company company : companies) {
				if (company.getId() == companyId) {
					CompanyFacade companyFacade = new CompanyFacade();
					companyFacade.setId(companyId);
					List<Coupon> companyCoupons = new ArrayList<>(companyFacade.getAllCompanyCoupons());
					for (Coupon coupons : companyCoupons) {
						companyFacade.deleteCompanyCoupon(coupons.getId());
					}
					CompanyDao dao = new CompanyDaoDbPreparedStatements();
					dao.delete(companyId);
					System.out.println("company deleted");
					return;
				}
			}
			System.out.println("company id not recognized");
		} catch (CompaniesException e) {
			throw new CompaniesException("delete company failed", e);
		}

	}

	public void addCustomer(Customer customer) {
		try {
			CustomerDao dao = new CustomerDaoDbPreparedStatements();
			dao.create(customer);
			System.out.println("customer Id: " + customer.getId() + " added successfully");
		} catch (CompaniesException e) {
			throw new CompaniesException("create customer failed", e);
		}

	}

	public Customer getCustomer(int customerId) {
		try {
			CustomerDao dao = new CustomerDaoDbPreparedStatements();
			return dao.read(customerId);
		} catch (CompaniesException e) {
			throw new CompaniesException("create customer failed", e);
		}
	}

	public List<Customer> getAllCustomers() {
		try {
			CustomerDao dao = new CustomerDaoDbPreparedStatements();
			return dao.readAll();
		} catch (CompaniesException e) {
			throw new CompaniesException("create customer failed", e);
		}
	}

	public void updateCustomer(Customer customer) {
		try {
			CustomerDao dao = new CustomerDaoDbPreparedStatements();
			dao.update(customer);
		} catch (CompaniesException e) {
			throw new CompaniesException("update customer failed", e);
		}

	}

	public void deleteCustomer(int customerId) {
		try {
			CustomerDao dao = new CustomerDaoDbPreparedStatements();
			dao.delete(customerId);
		} catch (CompaniesException e) {
			throw new CompaniesException("delete customer failed", e);
		}

	}

}
