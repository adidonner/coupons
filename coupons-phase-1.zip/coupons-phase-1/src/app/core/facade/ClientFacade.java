package app.core.facade;

import app.core.data.dao.CompanyDao;
import app.core.data.dao.CouponDao;
import app.core.data.dao.CustomerDao;

public abstract class ClientFacade {

	CompanyDao companyDao;
	
	CustomerDao customerDao;
	
	CouponDao couponDao;
	
	public boolean login(String email, String password) {
		return false;
	}
	

}