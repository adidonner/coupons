package app.core.facade;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import app.core.beans.Category;
import app.core.beans.Coupon;
import app.core.beans.Customer;
import app.core.beans.CustomerVsCoupon;
import app.core.data.dao.CouponDao;
import app.core.data.dao.CouponDaoDbPreparedStatements;
import app.core.data.dao.CustomerDao;
import app.core.data.dao.CustomerDaoDbPreparedStatements;
import app.core.data.dao.CustomerVsCouponDao;
import app.core.data.dao.CustomerVsCouponDaoDbPreparedStatements;
import app.core.exceptions.CouponsException;

public class CustomerFacade extends ClientFacade {

	public int customerId;

	public CustomerFacade() {
	}

	public CustomerFacade(int customerId) {
		this.customerId = customerId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public boolean login(String email, String password) {
		CustomerDao dao = new CustomerDaoDbPreparedStatements();
		List<Customer> customers = new ArrayList<>(dao.readAll());
		Iterator<Customer> it = customers.iterator();
		while (it.hasNext()) {
			Customer curr = it.next();
			if (curr.getEmail().equals(email) && curr.getPassword().equals(password)) {
				setCustomerId(curr.getId());
				System.out.println("Welcome " + curr.getFirstName() + " " + curr.getLastName() + " You are logged in");
				return true;
			}
		}
		System.out.println("Null");
		return false;
	}

	public Customer getCustomerDetails() {
		CustomerDao dao = new CustomerDaoDbPreparedStatements();
		return dao.read(getCustomerId());
	}

	public void purchaseCoupon(Coupon coupon) {
		try {
			CouponDao dao1 = new CouponDaoDbPreparedStatements();
			Coupon curr = dao1.read(coupon.getId());
			if (curr.getAmount() == 0) {
				System.out.println("no coupons of this type left");
				return;
			}
			if (curr.getEndDate().compareTo(LocalDate.now()) < 0) {
				System.out.println("coupon is out of date");
			}
			CustomerVsCouponDao dao = new CustomerVsCouponDaoDbPreparedStatements();
			List<CustomerVsCoupon> coupons = new ArrayList<>(dao.readAll());
			for (CustomerVsCoupon customerVsCoupon : coupons) {
				if(customerVsCoupon.getCustomerId() == getCustomerId() && customerVsCoupon.getCouponId() == coupon.getId()) {
					System.out.println("coupon was already purchased before");
					return;
				}
			}			
			CustomerVsCoupon customerVsCoupon = new CustomerVsCoupon(customerId, coupon.getId());
			dao.create(customerVsCoupon);
						
			Coupon couponUpdate = dao1.read(coupon.getId());
			couponUpdate.setAmount(couponUpdate.getAmount()-1);
			dao1.update(couponUpdate);
			
			System.out.println("coupon purchased successfully");
		} catch (CouponsException e) {
			throw new CouponsException("coupon not purchased", e);
		}

	}
	public void sellCoupon(int couponId) {
		try {
			CustomerVsCouponDao dao = new CustomerVsCouponDaoDbPreparedStatements();
			List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>(dao.readAll());
			for (CustomerVsCoupon customerVsCoupon : customerVsCoupons) {
				if(customerId == customerVsCoupon.getCustomerId() && couponId == customerVsCoupon.getCouponId()) {
					dao.deleteCoupon(couponId);
					System.out.println("coupon sold successfully");
					return;
				}
			}
			System.out.println("customer doesn't have this coupon");
		} catch (CouponsException e) {
			throw new CouponsException("coupon not purchased", e);
		}
		
	}

	public Coupon getOneCustomerCoupon(int couponId) {
		CouponDao dao = new CouponDaoDbPreparedStatements();
		return dao.read(couponId);
	}

	public List<Coupon> getAllCustomerCoupons() {
		CustomerVsCouponDao dao = new CustomerVsCouponDaoDbPreparedStatements();
		List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>(dao.readAll());
		List<Coupon> coupons = new ArrayList<>();
		for (CustomerVsCoupon customerVsCoupon : customerVsCoupons) {
			if (customerVsCoupon.getCustomerId() == getCustomerId()) {
				coupons.add(getOneCustomerCoupon(customerVsCoupon.getCouponId()));
			}
		}
		return coupons;
	}

	public List<Coupon> getCategoryCustomerCoupons(Category category) {
		List<Coupon> coupons = new ArrayList<>(getAllCustomerCoupons());
		List<Coupon> categoryCoupons = new ArrayList<>();
		for (Coupon coupon : coupons) {
			if (coupon.getCategory().equals(category)) {
				categoryCoupons.add(coupon);
			}
		}
		return categoryCoupons;
	}

	public List<Coupon> getAllMaxCustomerCoupons(double maxPrice) {
		try {
			List<Coupon> coupons = new ArrayList<>(getAllCustomerCoupons());
			List<Coupon> maxCoupons = new ArrayList<>();
			for (Coupon coupon : coupons) {
				if (coupon.getPrice() < maxPrice) {
					maxCoupons.add(coupon);
				}
			}
			return maxCoupons;
		} catch (Exception e) {
			throw new CouponsException("read coupons failed", e);
		}

	}
}
