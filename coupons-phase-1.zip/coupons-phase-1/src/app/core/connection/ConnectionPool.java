package app.core.connection;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import app.core.exceptions.CouponsException;

public class ConnectionPool {

	private String dbUrl = "jdbc:mysql://localhost:3306/coupons_db";
	private String dbUser = "root";
	private String dbPassword = "1234";

	private Set<Connection> set = new HashSet<>();
	public static final int MAX = 5;
	private static ConnectionPool instance = new ConnectionPool();

	private ConnectionPool() {

	}

	public static ConnectionPool getInstance() {
		return instance;
	}

	public void init() {
		try {
			for (int i = 0; i < MAX; i++) {
				Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
				set.add(con);
			}
		} catch (SQLException e) {
			throw new CouponsException("init connection pool failed", e);
		}
	}

	public synchronized Connection getConnection() {
		while (this.set.isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		Iterator<Connection> it = set.iterator();
		Connection con = it.next();
		it.remove();
		return con;
	}

	public synchronized void restoreConnection(Connection con) {
		// return to pool
		set.add(con);
		notifyAll();
	}

	public synchronized void closeAllConnections() {

		while (set.size() < MAX) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		try {
			for (Connection connection : set) {
				connection.close();
			}
		} catch (SQLException e) {
			throw new CouponsException("closeAllConnections failed", e);
		}

	}

}
