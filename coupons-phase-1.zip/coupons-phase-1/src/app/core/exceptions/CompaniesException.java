package app.core.exceptions;

public class CompaniesException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CompaniesException() {
		// TODO Auto-generated constructor stub
	}

	public CompaniesException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CompaniesException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public CompaniesException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CompaniesException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
