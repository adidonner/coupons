package app.core.data.dao;

import java.util.List;


import app.core.beans.Customer;
import app.core.exceptions.CustomersException;

// Data Access Object
public interface CustomerDao {

	int create(Customer customers) throws CustomersException;

	Customer read(int id) throws CustomersException;

	List<Customer> readAll() throws CustomersException;

	void update(Customer customers) throws CustomersException;

	void delete(int id) throws CustomersException;

}
