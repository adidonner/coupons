package app.core.data.dao;

import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import app.core.beans.Category;
import app.core.beans.Coupon;
import app.core.connection.ConnectionPool;
import app.core.exceptions.CouponsException;

public class CouponDaoDbPreparedStatements implements CouponDao {

	@Override
	public int create(Coupon coupons) throws CouponsException {
		String sql = "insert into coupons values(0,?,?,?,?,?,?,?,?,?)";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);) {

			pstmt.setInt(1, coupons.getCompanyId());
			pstmt.setString(2, String.valueOf(coupons.getCategory()));
			pstmt.setString(3, coupons.getTitle());
			pstmt.setString(4, coupons.getDescription());
			pstmt.setString(4, coupons.getDescription());
			pstmt.setDate(5, Date.valueOf(coupons.getStartDate()));
			pstmt.setDate(6, Date.valueOf(coupons.getEndDate()));
			pstmt.setInt(7, coupons.getAmount());
			pstmt.setDouble(8, coupons.getPrice());
			pstmt.setString(9, coupons.getImage());
			//
			pstmt.executeUpdate();
			ResultSet rsKeys = pstmt.getGeneratedKeys();
			rsKeys.next();
			int id = rsKeys.getInt(1);
			coupons.setId(id);
			System.out.println("coupon id:" + coupons.getId() +" created successfully");
			return id;
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CouponsException("create coupon failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public Coupon read(int id) throws CouponsException {
		String sql = "select * from coupons where id = ? ";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(id);
				coupon.setCompanyId(rs.getInt("company_id"));
				coupon.setCategory(Category.valueOf(rs.getString("category")));
				coupon.setTitle(rs.getString("title"));
				coupon.setDescription(rs.getString("description"));
				coupon.setStartDate(rs.getDate("start_date").toLocalDate());
				coupon.setEndDate(rs.getDate("end_date").toLocalDate());
				coupon.setAmount(rs.getInt("amount"));
				coupon.setPrice(rs.getDouble("price"));
				coupon.setImage(rs.getString("image"));
				return coupon;
			} else {
				throw new CouponsException("coupon " + id + " not found");
			}
		} catch (SQLException e) {
			throw new CouponsException("read coupon failed", e);
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
	}

	@Override
	public List<Coupon> readAll() throws CouponsException {
		String sql = "select * from coupons";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			ResultSet rs = stmt.executeQuery(sql);
			List<Coupon> coupons = new ArrayList<>();
			while (rs.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(rs.getInt("id"));
				coupon.setCompanyId(rs.getInt("company_id"));
				coupon.setCategory(Category.valueOf(rs.getString("category")));
				coupon.setTitle(rs.getString("title"));
				coupon.setDescription(rs.getString("description"));
				coupon.setStartDate(rs.getDate("start_date").toLocalDate());
				coupon.setEndDate(rs.getDate("end_date").toLocalDate());
				coupon.setAmount(rs.getInt("amount"));
				coupon.setPrice(rs.getDouble("price"));
				coupon.setImage(rs.getString("image"));
				coupons.add(coupon);
			}
			return coupons;
		} catch (SQLException e) {
			throw new CouponsException("read all failed", e);
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
	}

	@Override
	public void update(Coupon coupon) throws CouponsException {
		String sql = "update coupons set company_id = ?, category = ? ,title =  ?, ";
		sql += "description = ?, start_date = ?, end_date = ?, amount = ?, price = ?,";
		sql += "image = ? where id = " + coupon.getId();

		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {

			pstmt.setInt(1, coupon.getCompanyId());
			pstmt.setString(2, String.valueOf(coupon.getCategory()));
			pstmt.setString(3, coupon.getTitle());
			pstmt.setString(4, coupon.getDescription());
			pstmt.setDate(5, Date.valueOf(coupon.getStartDate()));
			pstmt.setDate(6, Date.valueOf(coupon.getEndDate()));
			pstmt.setInt(7, coupon.getAmount());
			pstmt.setDouble(8, coupon.getPrice());
			pstmt.setString(9, coupon.getImage());

			pstmt.executeUpdate();

			System.out.println("coupon id: " + coupon.getId() + " updated");
		} catch (SQLException e) {
			throw new CouponsException("update coupon failed", e);
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}

	}

	@Override
	public void delete(int id) throws CouponsException {

		String sql = "delete from coupons where id =" + id;
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			stmt.executeUpdate(sql);
			System.out.println("coupon id: " + id + " deleted");
		} catch (SQLException e) {
			throw new CouponsException("delete coupon failed", e);
		} finally {
			ConnectionPool.getInstance().restoreConnection(con);
		}
	}

}
