package app.core.data.dao;

import java.util.List;


import app.core.beans.Coupon;
import app.core.exceptions.CouponsException;

public interface CouponDao {

	int create(Coupon coupons) throws CouponsException;

	Coupon read(int id) throws CouponsException;

	List<Coupon> readAll() throws CouponsException;

	void update(Coupon coupons) throws CouponsException;

	void delete(int id) throws CouponsException;

}
