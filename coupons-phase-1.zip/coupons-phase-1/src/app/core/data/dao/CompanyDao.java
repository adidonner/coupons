package app.core.data.dao;

import java.util.List;

import app.core.beans.Company;
import app.core.exceptions.CompaniesException;

// Data Access Object
public interface CompanyDao {

	int create(Company company) throws CompaniesException;

	Company read(int id) throws CompaniesException;

	List<Company> readAll() throws CompaniesException;

	void update(Company company) throws CompaniesException;

	void delete(int id) throws CompaniesException;

}
