package app.core.data.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import app.core.beans.Customer;
import app.core.connection.ConnectionPool;
import app.core.exceptions.CustomersException;

public class CustomerDaoDbPreparedStatements implements CustomerDao {

	@Override
	public int create(Customer customers) throws CustomersException {
		String sql = "insert into customers values(0,?,?,?,?)";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);) {
			pstmt.setString(1, customers.getFirstName());
			pstmt.setString(2, customers.getLastName());
			pstmt.setString(3, customers.getEmail());
			pstmt.setString(4, customers.getPassword());
			pstmt.executeUpdate();
			
			ResultSet rsKeys = pstmt.getGeneratedKeys();
			rsKeys.next();
			int id = rsKeys.getInt(1);
			customers.setId(id); // set the costumer id from the database
			return id; // return the generated id
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CustomersException("create customer failed", e);
		}finally {
			if(con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public Customer read(int id) throws CustomersException {
		String sql = "select * from customers where id = ? ";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1,id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				Customer customer = new Customer();
				customer.setId(id); 
				customer.setFirstName(rs.getString("first_name")); 
				customer.setLastName(rs.getString("last_name")); 
				customer.setEmail(rs.getString("email")); 
				customer.setPassword(rs.getString("password")); 
				return customer; 
			} else {
				throw new CustomersException("read customer failed - id " + id +" not found");
			}
		} catch (SQLException e) {
			throw new CustomersException("read customer failed", e);
		}finally {
			if(con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public List<Customer> readAll() throws CustomersException {
		String sql = "select * from customers";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			ResultSet rs = stmt.executeQuery(sql);
			List<Customer> customers = new ArrayList<>();
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getInt("id"));
				customer.setFirstName(rs.getString("first_name")); 
				customer.setLastName(rs.getString("last_name")); 
				customer.setEmail(rs.getString("email")); 
				customer.setPassword(rs.getString("password"));				
				customers.add(customer);
			}
			return customers;
		} catch (SQLException e) {
			throw new CustomersException("read all failed", e);
		}finally {
			if(con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public void update(Customer customer) throws CustomersException {
		String sql = "update customers set first_name = '" + customer.getFirstName() + "', last_name = '" + customer.getLastName() + "', email = '" + customer.getEmail() + "' ";
		sql += ", password = '" + customer.getPassword()+ "' where id = " + customer.getId();
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			System.out.println("update" + customer + " succussfully");
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.out.println("======================");
			System.out.println(sql);
			System.out.println("======================");
			throw new CustomersException("update customer failed", e);
		}finally {
			if(con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}

	}

	@Override
	public void delete(int id) throws CustomersException {
		String sql = "delete from customers where id =" + id;
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();){
			System.out.println("delete customer id: " + id + " succussfully");
			stmt.executeUpdate(sql);			
		} catch (SQLException e) {
				System.out.println(sql);
				throw new CustomersException("delete user failed", e);
		}finally {
			if(con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

}
