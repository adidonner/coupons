package app.core.data.dao;

import java.util.List;

import app.core.beans.Category;
import app.core.beans.CustomerVsCoupon;
import app.core.exceptions.CouponsException;

public interface CustomerVsCouponDao{
	
	int create (CustomerVsCoupon customersVsCoupons) throws CouponsException;
	
	List<CustomerVsCoupon> read(int id) throws CouponsException;
	
	List<CustomerVsCoupon> readAll() throws CouponsException;
		
	void deleteCustomer(int customerId) throws CouponsException;

	void deleteCoupon(int couponId) throws CouponsException;

	void deleteOneCouponFromCustomer(int customerId, int couponId) throws CouponsException;

	List<CustomerVsCoupon> read(int customerId, Category category) throws CouponsException;

	List<CustomerVsCoupon> read(int customerId, double maxPrice) throws CouponsException;

}
