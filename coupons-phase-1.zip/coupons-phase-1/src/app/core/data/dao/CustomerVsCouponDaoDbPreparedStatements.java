package app.core.data.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import app.core.beans.Category;
import app.core.beans.CustomerVsCoupon;
import app.core.connection.ConnectionPool;
import app.core.exceptions.CouponsException;
import app.core.exceptions.CustomersException;

public class CustomerVsCouponDaoDbPreparedStatements implements CustomerVsCouponDao {

	@Override
	public int create(CustomerVsCoupon customersVsCoupons) throws CouponsException {
		String sql = "insert into customers_vs_coupons values(?,?);";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, customersVsCoupons.getCustomerId());
			pstmt.setInt(2, customersVsCoupons.getCouponId());
			pstmt.executeUpdate();
			return customersVsCoupons.getCouponId();
		} catch (Exception e) {
			System.out.println(sql);
			throw new CustomersException("create customerVsCoupon failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public List<CustomerVsCoupon> read(int customerId) throws CouponsException {
		String sql = "Select * from customers_vs_coupons where customer_id = ? ";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, customerId);
			ResultSet rs = pstmt.executeQuery();
			List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>();
			while (rs.next()) {
				CustomerVsCoupon customerVsCoupon = new CustomerVsCoupon();
				customerVsCoupon.setCustomerId(rs.getInt("customer_id"));
				customerVsCoupon.setCouponId(rs.getInt("coupon_id"));
				customerVsCoupons.add(customerVsCoupon);
			}
			return customerVsCoupons;
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CouponsException("create customerVsClient failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public List<CustomerVsCoupon> read(int customerId, Category category) throws CouponsException {
		String sql = "select customers.id, coupons.id, coupons.category from customers";
		sql += " join coupons where customers.id = ? and coupons.category = ?;";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, customerId);
			pstmt.setString(2, String.valueOf(category));
			ResultSet rs = pstmt.executeQuery();
			List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>();
			while (rs.next()) {
				CustomerVsCoupon customerVsCoupon = new CustomerVsCoupon();
				customerVsCoupon.setCustomerId(rs.getInt("customers.id"));
				customerVsCoupon.setCouponId(rs.getInt("coupons.id"));
				customerVsCoupons.add(customerVsCoupon);
			}
			return customerVsCoupons;
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CouponsException("create customerVsClient failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public List<CustomerVsCoupon> read(int customerId, double maxPrice) throws CouponsException {
		String sql = "Select * from customers_vs_coupons where customer_id = ? ";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, customerId);
			ResultSet rs = pstmt.executeQuery();
			List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>();
			while (rs.next()) {
				CustomerVsCoupon customerVsCoupon = new CustomerVsCoupon();
				customerVsCoupon.setCustomerId(rs.getInt("customer_id"));
				customerVsCoupon.setCouponId(rs.getInt("coupon_id"));
				customerVsCoupons.add(customerVsCoupon);
			}
			return customerVsCoupons;
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CouponsException("create customerVsClient failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public List<CustomerVsCoupon> readAll() throws CouponsException {
		String sql = "select * from customers_vs_coupons;";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			ResultSet rs = stmt.executeQuery(sql);
			List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>();
			while (rs.next()) {
				CustomerVsCoupon customerVsCoupon = new CustomerVsCoupon();
				customerVsCoupon.setCustomerId(rs.getInt("customer_id"));
				customerVsCoupon.setCouponId(rs.getInt("coupon_id"));
				customerVsCoupons.add(customerVsCoupon);
			}
			return customerVsCoupons;
		} catch (SQLException e) {
			throw new CustomersException("read customerVsCoupon read failed failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}

	}

	@Override
	public void deleteCustomer(int customerId) throws CouponsException {
		String sql = "delete from customers_vs_coupons where customer_id =" + customerId;
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			stmt.executeUpdate(sql);
			System.out.println("delete customer" + customerId + " with coupons successfull");
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CouponsException();
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public void deleteCoupon(int couponId) throws CouponsException {
		String sql = "delete from customers_vs_coupons where coupon_id =" + couponId;
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CouponsException("delete coupon/s failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public void deleteOneCouponFromCustomer(int customerId, int couponId) throws CouponsException {
		String sql = "delete from customers_vs_coupons where customer_id =" + customerId + " and coupon_id ="
				+ couponId;
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CouponsException("delete coupon/s failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}

	}
}
