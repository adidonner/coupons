package app.core.data.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import app.core.beans.Company;
import app.core.connection.ConnectionPool;
import app.core.exceptions.CompaniesException;

public class CompanyDaoDbPreparedStatements implements CompanyDao {

	@Override
	public int create(Company company) throws CompaniesException {
		String sql = "insert into companies values(0,?,?,?)";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);) {
			pstmt.setString(1, company.getName());
			pstmt.setString(2, company.getEmail());
			pstmt.setString(3, company.getPassword());
			pstmt.executeUpdate();
			ResultSet rsKeys = pstmt.getGeneratedKeys();
			rsKeys.next();
			int id = rsKeys.getInt(1);
			company.setId(id); // set the company id from the database
			return id; // return the generated id
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CompaniesException("create company failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public Company read(int id) throws CompaniesException {
		String sql = "select * from companies where id = ? ";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (PreparedStatement pstmt = con.prepareStatement(sql);) {
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				Company company = new Company();
				company.setId(id);
				company.setName(rs.getString("name"));
				company.setEmail(rs.getString("email"));
				company.setPassword(rs.getString("password"));
				return company;
			} else {
				throw new CompaniesException("read company failed - id " + id + " not found");
			}
		} catch (SQLException e) {
			throw new CompaniesException("read company failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public List<Company> readAll() throws CompaniesException {
		String sql = "select * from companies";
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			ResultSet rs = stmt.executeQuery(sql);
			List<Company> companies = new ArrayList<>();
			while (rs.next()) {
				Company company = new Company();
				company.setId(rs.getInt("id"));
				company.setName(rs.getString("name"));
				company.setEmail(rs.getString("email"));
				company.setPassword(rs.getString("password"));
				companies.add(company);
			}
			return companies;
		} catch (SQLException e) {
			throw new CompaniesException("read all failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

	@Override
	public void update(Company company) throws CompaniesException {
		String sql = "update companies set name = '" + company.getName() + "', email = '" + company.getEmail()
				+ "', password = '" + company.getPassword() + "' ";
		sql += "where id = " + company.getId();
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			stmt.executeUpdate(sql);
			System.out.println("update" + company + " succussfully");
		} catch (SQLException e) {
			throw new CompaniesException("update company failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}

	}

	@Override
	public void delete(int id) throws CompaniesException {

		String sql = "delete from companies where id =" + id;
		Connection con = ConnectionPool.getInstance().getConnection();
		try (Statement stmt = con.createStatement();) {
			stmt.executeUpdate(sql);
			System.out.println("company Id: " + id + " deleted successfully");
		} catch (SQLException e) {
			System.out.println(sql);
			throw new CompaniesException("delete company failed", e);
		} finally {
			if (con != null) {
				ConnectionPool.getInstance().restoreConnection(con);
			}
		}
	}

}
