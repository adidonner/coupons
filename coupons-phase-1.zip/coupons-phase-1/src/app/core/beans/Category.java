package app.core.beans;

public enum Category {
	SPORTS, CLOTHINGS, ELECTRICITY, CAMPING, FOOD, RESTAURANTS, VACATIONS 
}
