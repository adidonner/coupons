package app.core.job;

import java.util.concurrent.TimeUnit;

import app.core.connection.ConnectionPool;

public class appStartEnd {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("starting connection pool");
		ConnectionPool.getInstance().init();
		CouponExpirationDailyJob jobRunable = new CouponExpirationDailyJob();
		Thread jobThread = new Thread(jobRunable);
		System.out.println("starting job");
		jobThread.start();
		
		TimeUnit.SECONDS.sleep(10);
		
		System.out.println("stoping job");
		jobRunable.stop();
		jobThread.join();
		
		System.out.println("closing connection pool");
		ConnectionPool.getInstance().closeAllConnections();
		
	}

}
