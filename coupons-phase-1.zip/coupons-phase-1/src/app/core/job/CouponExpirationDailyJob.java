

package app.core.job;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import app.core.beans.Coupon;
import app.core.beans.CustomerVsCoupon;
import app.core.data.dao.CouponDao;
import app.core.data.dao.CouponDaoDbPreparedStatements;
import app.core.data.dao.CustomerVsCouponDao;
import app.core.data.dao.CustomerVsCouponDaoDbPreparedStatements;

public class CouponExpirationDailyJob implements Runnable {

	private boolean quit = false;

	public CouponExpirationDailyJob() {
		super();
	}

	@Override
	public void run() {
		System.out.println("CouponExpirationDailyJob started");
		while (!quit) {
			CouponDao dao = new CouponDaoDbPreparedStatements();
			List<Coupon> coupons = new ArrayList<>(dao.readAll());
			Iterator<Coupon> it = coupons.iterator();
			while (it.hasNext()) {
				Coupon curr = it.next();
				if (curr.getEndDate().compareTo(LocalDate.now()) < 0) {
					System.out.println(curr + "date expieresd");
					CustomerVsCouponDao dao1 = new CustomerVsCouponDaoDbPreparedStatements();// delete from
					List<CustomerVsCoupon> customerVsCoupons = new ArrayList<>(dao1.readAll());
					Iterator<CustomerVsCoupon> it1 = customerVsCoupons.iterator();
					while (it1.hasNext()) {
						CustomerVsCoupon curr1 = it1.next();
						if (curr1.getCouponId() == curr.getId()) {
							dao1.deleteCoupon(curr1.getCouponId());
							System.out.println("coupon deleted from customer's history");
						}
					}
					System.out.println("coupon id: " + curr.getId() + " deleted");
					dao.delete(curr.getId());
				}
			}
		}

	}

	public void stop() {
		System.out.println("Coupon Expiration Daily Job stopped");
		quit = true;

	}

}
